package com.example.bankapp;

import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.JavascriptInterface;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    public class JSBridge {
        @JavascriptInterface
        public void receiveData(String data){
            System.out.println("Received: " + data);
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        WebView web=new WebView(this);
        setContentView(web);

        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);

        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new JSBridge(), "AndroidBridge");

        web.loadUrl("file:///android_asset/account.html");
    }
}
